<?php return array('dependencies' => array('react', 'wp-hooks'), 'version' => 'a69371b31d86af37aa1d');
