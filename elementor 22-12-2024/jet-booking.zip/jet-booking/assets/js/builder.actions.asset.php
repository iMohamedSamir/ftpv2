<?php return array('dependencies' => array('react'), 'version' => 'a22f1d3cf505dd3108a6');
