import {
	Flex,
} from '@wordpress/components';
import {
	WideLine,
} from 'jet-form-builder-components';
import { ValidatedSelectControl } from 'jet-form-builder-actions';
import { __ } from '@wordpress/i18n';
import FieldsMapRow from './FieldsMapRow.jsx';
import { useFields } from 'jet-form-builder-blocks-to-actions';

function EditUpdateBooking( props ) {
	const {
		      settings,
		      onChangeSettingObj,
	      } = props;

	const formFields = useFields( { withInner: false, placeholder: '--' } );

	return <Flex direction="column">
		<ValidatedSelectControl
			label={ __( 'Booking ID', 'jet-booking' ) }
			value={ settings.booking_field_id }
			onChange={ val => onChangeSettingObj( {
				booking_field_id: val,
			} ) }
			options={ formFields }
			isErrorSupported={ ( { property } ) => (
				'booking_field_id' === property
			) }
			required
		/>
		<WideLine/>
		<ValidatedSelectControl
			label={ __( 'Check-in/out date field', 'jet-booking' ) }
			value={ settings.booking_dates_field }
			onChange={ val => onChangeSettingObj( {
				booking_dates_field: val,
			} ) }
			options={ formFields }
		/>
		<WideLine/>
		<FieldsMapRow { ...props }/>
	</Flex>;
}

export default EditUpdateBooking;