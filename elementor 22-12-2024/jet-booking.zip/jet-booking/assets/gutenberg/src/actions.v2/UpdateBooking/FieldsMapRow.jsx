/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';
import {
	Label,
	RowControl,
	RowControlEnd,
	Help,
} from 'jet-form-builder-components';
import { useFields } from 'jet-form-builder-blocks-to-actions';
import { FieldsMapField } from 'jet-form-builder-actions';
import { useMemo } from '@wordpress/element';

function FieldsMapRow( { settings, onChangeSettingObj, source } ) {

	const formFields = useFields( {
		withInner: false,
		placeholder: '--',
	} );

	const bookingFields = useMemo( () => {
		return source.bookingFields.map( field => {
			return 'string' === typeof field
			       ? { value: field, label: field }
			       : field;
		} );
	}, [] );

	return <RowControl createId={ false }>
		<Label>
			{ __(
				'Fields map',
				'jet-booking',
			) }
		</Label>
		<RowControlEnd gap={ 4 }>
			<Help>
				{ __(
					'Set booking properties to save appropriate form fields into.',
					'jet-booking',
				) }
			</Help>
			{ bookingFields.map( ( field ) => <FieldsMapField
				key={ field.value }
				help={ 'apartment_id' === field.value && __(
					'Note: changing the value in this field will not reinitialize the Check in/out field.',
					'jet-booking',
				) }
				tag={ field.value }
				label={ field.label }
				isRequired={ field.required }
				formFields={ formFields }
				value={ settings[ `booking_field_${ field.value }` ] }
				onChange={ val => onChangeSettingObj( {
					[ `booking_field_${ field.value }` ]: val,
				} ) }
			/> ) }
		</RowControlEnd>
	</RowControl>;
}

export default FieldsMapRow;
