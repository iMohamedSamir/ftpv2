import EditUpdateBooking from './Edit.jsx';
import { __ } from '@wordpress/i18n';
import { home } from '@wordpress/icons';

export default {
	type: 'update_booking',
	label: __( 'Update Booking', 'jet-booking' ),
	edit: EditUpdateBooking,
	docHref: 'https://crocoblock.com/knowledge-base/jetbooking/how-to-create-a-booking-form/',
	icon: home,
	validators: [
		( { settings } ) => {
			return settings?.booking_field_id
			       ? false
			       : { property: 'booking_field_id' };
		},
	],
};