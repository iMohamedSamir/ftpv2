import createBooking from './ApartmentBooking';
import updateBooking from './UpdateBooking';
import { registerAction } from 'jet-form-builder-actions';

registerAction( createBooking );
registerAction( updateBooking );
