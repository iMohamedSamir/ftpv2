/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';
import {
	Label,
	RowControl,
	RowControlEnd,
	Help,
} from 'jet-form-builder-components';
import { useFields } from 'jet-form-builder-blocks-to-actions';
import { FieldsMapField } from 'jet-form-builder-actions';

function DBColumnsMapRow( { settings, onChangeSettingObj } ) {

	const formFields = useFields( {
		withInner: false,
		placeholder: '--',
	} );

	return <RowControl createId={ false }>
		<Label>
			{ __(
				'DB columns map',
				'jet-booking',
			) }
		</Label>
		<RowControlEnd gap={ 4 }>
			<Help>
				{ __(
					'Set up connection between form fields and additional database table columns. This allows you to save entered field data in the corresponding DB column.',
					'jet-booking',
				) }
			</Help>
			{ JetBookingActionData.columns.map( ( field ) => <FieldsMapField
				key={ field }
				tag={ field }
				label={ field }
				formFields={ formFields }
				value={ settings[ `db_columns_map_${ field }` ] }
				onChange={ val => onChangeSettingObj( {
					[ `db_columns_map_${ field }` ]: val,
				} ) }
			/> ) }
		</RowControlEnd>
	</RowControl>;
}

export default DBColumnsMapRow;
