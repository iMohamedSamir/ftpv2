import { useState } from '@wordpress/element';
import {
	Button,
	Flex,
	FlexItem,
	ToggleControl,
} from '@wordpress/components';
import {
	WideLine,
	RowControl,
	RowControlEnd,
	Label,
	Help,
	ClearBaseControlStyle,
} from 'jet-form-builder-components';
import { ValidatedSelectControl } from 'jet-form-builder-actions';
import { __ } from '@wordpress/i18n';
import EditWCDetailsModal from './EditWCDetailsModal.jsx';
import FieldsMapRow from './FieldsMapRow.jsx';
import { useFields } from 'jet-form-builder-blocks-to-actions';
import DBColumnsMapRow from './DBColumnsMapRow';

function EditApartmentBooking( props ) {
	const {
		      settings,
		      onChangeSettingObj,
	      } = props;

	const formFields = useFields( { withInner: false, placeholder: '--' } );

	const [ wcDetailsModal, setWcDetailsModal ] = useState( false );

	return <Flex direction="column">
		<ValidatedSelectControl
			label={ __( 'Apartment ID field', 'jet-booking' ) }
			value={ settings.booking_apartment_field }
			onChange={ val => onChangeSettingObj( {
				booking_apartment_field: val,
			} ) }
			options={ formFields }
			isErrorSupported={ ( { property } ) => (
				'booking_apartment_field' === property
			) }
			required
		/>
		<WideLine/>
		<ValidatedSelectControl
			label={ __( 'Check-in/out date field', 'jet-booking' ) }
			value={ settings.booking_dates_field }
			onChange={ val => onChangeSettingObj( {
				booking_dates_field: val,
			} ) }
			options={ formFields }
			isErrorSupported={ ( { property } ) => (
				'booking_dates_field' === property
			) }
			required
		/>
		{ Boolean( JetBookingActionData?.columns?.length ) && <>
			<WideLine/>
			<DBColumnsMapRow { ...props }/>
		</> }
		{ Boolean( JetBookingActionData.wc_integration ) && <>
			<WideLine/>
			<ToggleControl
				className={ ClearBaseControlStyle }
				label={ __(
					'Disable WooCommerce integration',
					'jet-booking',
				) }
				help={ __(
					'Check to disable WooCommerce integration and disconnect the booking system with WooCommerce checkout for current form.',
					'jet-booking',
				) }
				checked={ settings.disable_wc_integration }
				onChange={ val => onChangeSettingObj( {
					disable_wc_integration: val,
				} ) }
				__nextHasNoMarginBottom
			/>
			{ !Boolean( settings.disable_wc_integration ) && <>
				<WideLine/>
				<ValidatedSelectControl
					label={ __( 'WooCommerce Price field', 'jet-booking' ) }
					help={ __(
						'Select field to get total price from. If not selected price will be get from post meta value.',
						'jet-booking' ) }
					value={ settings.booking_wc_price }
					onChange={ val => onChangeSettingObj( {
						booking_wc_price: val,
					} ) }
					options={ formFields }
				/>
				<WideLine/>
				<RowControl createId={ false }>
					<Label>
						{ __( 'WooCommerce order details',
							'jet-form-builder-woo-action' ) }
					</Label>
					<RowControlEnd>
						<FlexItem>
							<Button
								variant="secondary"
								onClick={ () => setWcDetailsModal( true ) }
							>
								{ __( 'Set up', 'jet-booking' ) }
							</Button>
						</FlexItem>
						<Help>
							{ __(
								'Set up booking-related info you want to add to the WooCommerce orders and e-mails.',
								'jet-booking',
							) }
						</Help>
					</RowControlEnd>
				</RowControl>
				<WideLine/>
				<FieldsMapRow { ...props }/>
			</> }
		</> }
		{ wcDetailsModal && <EditWCDetailsModal
			setIsShow={ setWcDetailsModal }
		/> }
	</Flex>;
}

export default EditApartmentBooking;