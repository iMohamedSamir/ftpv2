import { ExternalLink, Flex, TextControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { useContext } from '@wordpress/element';
import {
	Label,
	RowControl,
	RowControlEnd,
	WideLine,
	Help,
} from 'jet-form-builder-components';
import {
	ValidatedSelectControl,
	ValidatedTextControl,
} from 'jet-form-builder-actions';

const { RepeaterItemContext } = JetFBComponents;

const detailsTypes = [
	{
		'value': '',
		'label': __( 'Select type...', 'jet-booking' ),
	},
	{
		'value': 'booked-inst',
		'label': __( 'Booked instance name', 'jet-booking' ),
	},
	{
		'value': 'check-in',
		'label': __( 'Check in', 'jet-booking' ),
	},
	{
		'value': 'check-out',
		'label': __( 'Check out', 'jet-booking' ),
	},
	{
		'value': 'unit',
		'label': __( 'Booking unit', 'jet-booking' ),
	},
	{
		'value': 'field',
		'label': __( 'Form field', 'jet-booking' ),
	},
	{
		'value': 'add_to_calendar',
		'label': __( 'Add to Google calendar link', 'jet-booking' ),
	},
];

function EditWCDetailModalItem( { formFields } ) {

	const {
		      currentItem,
		      changeCurrentItem,
	      } = useContext( RepeaterItemContext );

	return <Flex direction="column">
		<ValidatedSelectControl
			label={ __( 'Type', 'jet-booking' ) }
			value={ currentItem.type }
			onChange={ type => changeCurrentItem( { type } ) }
			options={ detailsTypes }
			__next40pxDefaultSize
			__nextHasNoMarginBottom
		/>
		<WideLine/>
		<ValidatedTextControl
			label={ __( 'Label', 'jet-booking' ) }
			value={ currentItem.label }
			onChange={ label => changeCurrentItem( { label } ) }
			__next40pxDefaultSize
			__nextHasNoMarginBottom
		/>
		{ [ 'check-in', 'check-out' ].includes( currentItem.type ) && <>
			<WideLine/>
			<RowControl>
				{ ( { id } ) => <>
					<Label htmlFor={ id }>
						{ __( 'Date format', 'jet-booking' ) }
					</Label>
					<RowControlEnd>
						<TextControl
							id={ id }
							value={ currentItem.format }
							onChange={ format => changeCurrentItem(
								{ format },
							) }
							__next40pxDefaultSize
							__nextHasNoMarginBottom
						/>
						<Help>
							<ExternalLink
								href="https://codex.wordpress.org/Formatting_Date_and_Time">
								{ __( 'Formatting docs', 'jet-booking' ) }
							</ExternalLink>
						</Help>
					</RowControlEnd>
				</> }
			</RowControl>

		</> }
		{ 'field' === currentItem.type && <>
			<WideLine/>
			<ValidatedSelectControl
				label={ __( 'Select form field', 'jet-booking' ) }
				value={ currentItem.field }
				onChange={ field => changeCurrentItem( { field } ) }
				options={ formFields }
				__next40pxDefaultSize
				__nextHasNoMarginBottom
			/>
		</> }
		{ 'add_to_calendar' === currentItem.type && <>
			<WideLine/>
			<ValidatedTextControl
				label={ __( 'Link text', 'jet-booking' ) }
				value={ currentItem.link_label }
				onChange={ val => changeCurrentItem( { link_label: val } ) }
				__next40pxDefaultSize
				__nextHasNoMarginBottom
			/>
		</> }
	</Flex>;
}

export default EditWCDetailModalItem;