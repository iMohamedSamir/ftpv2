import EditApartmentBooking from './Edit.jsx';
import { __ } from '@wordpress/i18n';
import { home } from '@wordpress/icons';

export default {
	type: 'apartment_booking',
	label: __( 'Apartment Booking', 'jet-booking' ),
	edit: EditApartmentBooking,
	docHref: 'https://crocoblock.com/knowledge-base/jetbooking/how-to-create-a-booking-form/',
	icon: home,
	validators: [
		( { settings } ) => {
			return settings?.booking_apartment_field
			       ? false
			       : { property: 'booking_apartment_field' };
		},
		( { settings } ) => {
			return settings?.booking_dates_field
			       ? false
			       : { property: 'booking_dates_field' };
		},
	],
};