/* eslint-disable import/no-extraneous-dependencies */
import { __ } from '@wordpress/i18n';
import {
	Label,
	RowControl,
	RowControlEnd,
	Help,
} from 'jet-form-builder-components';
import { useFields } from 'jet-form-builder-blocks-to-actions';
import { FieldsMapField } from 'jet-form-builder-actions';

function FieldsMapRow( { settings, onChangeSettingObj } ) {

	const formFields = useFields( {
		withInner: false,
		placeholder: '--',
	} );

	return <RowControl createId={ false }>
		<Label>
			{ __(
				'WooCommerce checkout fields map',
				'jet-booking',
			) }
		</Label>
		<RowControlEnd gap={ 4 }>
			<Help>
				{ __(
					'Connect WooCommerce checkout fields to appropriate form fields. This allows you to pre-fill WooCommerce checkout fields after redirect to checkout.',
					'jet-booking',
				) }
			</Help>
			{ JetBookingActionData.wc_fields.map( ( field ) => <FieldsMapField
				key={ field }
				tag={ field }
				label={ field }
				formFields={ formFields }
				value={ settings[ `wc_fields_map__${ field }` ] }
				onChange={ val => onChangeSettingObj( {
					[ `wc_fields_map__${ field }` ]: val,
				} ) }
			/> ) }
		</RowControlEnd>
	</RowControl>;
}

export default FieldsMapRow;
