<?php
/**
 * Results Item js template
 */
?>

<div class="jet-ajax-search__results-suggestions-area-item" tabindex="0" aria-label="{{{data.fullName}}}">
	<div class="jet-ajax-search__results-suggestions-area-item-title">{{{data.name}}}</div>
</div>
