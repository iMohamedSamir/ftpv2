<?php
/**
 * Spinner template
 */
?>

<div class="jet-ajax-search__spinner-holder">
	<div class="jet-ajax-search__spinner">
		<div class="rect rect-1"></div>
		<div class="rect rect-2"></div>
		<div class="rect rect-3"></div>
		<div class="rect rect-4"></div>
		<div class="rect rect-5"></div>
	</div>
</div>
