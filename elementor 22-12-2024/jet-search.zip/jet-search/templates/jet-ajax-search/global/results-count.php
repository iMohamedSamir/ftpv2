<?php
/**
 * Results Count template
 */
?>

<button class="jet-ajax-search__results-count"><span></span> <?php $this->html( 'results_counter_text', '%s' ); ?></button>
