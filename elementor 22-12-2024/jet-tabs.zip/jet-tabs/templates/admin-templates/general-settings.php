<div
	class="jet-tabs-settings-page jet-tabs-settings-page__general"
>
	<cx-vui-select
		name="widgets-load-level"
		label="<?php _e( 'Editor Load Level', 'jet-tabs' ); ?>"
		description="<?php _e( 'Choose a certain set of options in the widget’s Style tab by moving the slider, and improve your Elementor editor performance by selecting appropriate style settings fill level (from None to Full level)', 'jet-tricks' ); ?>"
		:wrapper-css="[ 'equalwidth' ]"
		size="fullwidth"
		:options-list="pageOptions.widgets_load_level.options"
		v-model="pageOptions.widgets_load_level.value">
	</cx-vui-select>

    <cx-vui-select
            name="ajax-request-type"
            label="<?php _e( 'Ajax Request Type', 'jet-tabs' ); ?>"
            description="<?php _e( 'Choose the type of AJAX request.', 'jet-tabs' ); ?>"
            :wrapper-css="[ 'equalwidth' ]"
            size="fullwidth"
            :options-list="pageOptions.ajax_request_type.options"
            v-model="pageOptions.ajax_request_type.value">
    </cx-vui-select>
</div>
