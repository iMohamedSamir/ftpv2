import action from './InsertAppointment';
import { registerAction } from 'jet-form-builder-actions';

registerAction( action );
