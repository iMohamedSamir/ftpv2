<?php


namespace JET_APB\Form_Fields;


use JET_APB\Vendor\Fields_Core\Smart_Field_Trait;

class Provider_Field_Render {

	use Smart_Field_Trait;
	use Provider_Field_Template_Trait;

}